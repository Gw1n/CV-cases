#include "search.h"
#include <iostream>

using std::endl;
using std::cout;
using std::cin;

void read( int *a, int* offset, int max_size ) 
{
    while ((*offset <= max_size) && (!cin.eof()))
    {
        cout << "*a(+" << *offset << "): ";
        cin >> a[*offset];
        (*offset)++;
    }
    
    if (cin.eof())
    {
        cin.clear();
        (*offset)--;
    }
}

void print( const int *a, int size ) 
{
    for (int i = 0; i < size; i++)
    {
        cout << a[i] << " ";
    }
}

bool isSorted( const int *a, int size ) 
{
    for (int i = 0; i < size-1; i++)
    {
        if (a[i] > a[i+1])
        {
            return 0;
        }
    }
    return 1;
}

const int* binarySearch( const int *start, const int *end, int key ) 
{
    cout << "From " << *start << " to " << *end << endl; 
    if (*start > *end)
    {
        return nullptr;
    }
    const int* middle = start + (end - start)/2;
    if (*middle == key) {return middle;}
    if (key > *middle) {return binarySearch(middle+1, end, key);}
    return binarySearch(start, middle-1, key);
}

const int* binarySearchIt( const int *start, const int *end, int key ) 
{
    const int* middle = start + (end - start)/2;
    while (*middle != key)
    {
        middle = start + (end - start)/2;
        cout << "From " << *start << " to " << *end << endl; 
        if (*middle == key) {return middle;}
        if (key > *middle) 
        {
            start = middle+1;
        }
        else
        {
            end = middle-1;
        }
    }
}