#ifndef _SEARCH_H_
#define _SEARCH_H_

#include <iostream>

void read( int *a, int* offset, int max_size );
void print( const int *a, int size ); 
bool isSorted( const int *a, int size );
const int* binarySearch( const int *start, const int *end, int key );   
const int* binarySearchIt( const int *array, const int *end, int key );

#endif