#include "search.h"

using std::cout;
using std::cin;
using std::endl;

// Main function to test binary search

int main(){                                                                                          
    // Data                                                                                          
    const int max_size = 100;                                                                        
    int a[max_size];                                                                                 
    int size = 0;                                                                                    
    int *a_ptr = a;
    
    // Test read function                                                                            
    cout << "Enter integers. Terminate with EOF." << endl;                                           
    read(a_ptr, &size, max_size);                                                                     
    cout << "The array has " << size << " elements: ";                                           
    // Test print function                                                                           
    print(a_ptr, size);                                                                              
    cout << endl;
    
    // Test isSorted function
    if(isSorted(a_ptr, size)) {
        // Test binarySearch function                                                                    
        cout << "Please enter search key: ";                                                             
        int key;                                                                                         
        cin >> key;                                                                                      
        const int* index = binarySearch(a_ptr, a_ptr+size-1, key);                                                   
        if(index != nullptr) {                                                                                
            cout << "Search key was found at address: " << index << endl;                                  
        } else {                                                                                         
            cout << "Search key not found among array elements." << endl;                                
        }
        // Test binarySearch function iteratively                                                                    
        index = binarySearchIt(a_ptr, a_ptr+size-1, key);                                                   
        if(index != nullptr) {                                                                                
            cout << "Search key was found at address: " << index << endl;                                  
        } else {                                                                                         
            cout << "Search key not found among array elements." << endl;                                
        }
    } else {
        cout << "Array is not sorted!" << endl;
    }
    
                                                                                                     
} 