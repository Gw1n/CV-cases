#include "search.h"
#include <iostream>

void read( int a[], int& size_ref, int max_size )
{
    size_ref = 0;
    while ((size_ref < max_size) && (!std::cin.eof()))
    {
        std::cout << "a[" << size_ref << "]: ";
        std::cin >> a[size_ref];
        size_ref++;
    }
    if (std::cin.eof())
        {
            std::cin.clear();
            size_ref--;
        }
}

void print( const int a[], int size )
{
    for (int i = 0; i < size; i++)
    {
        std::cout << a[i] << " ";
    }
    //std::cout << std::endl;
}

int linearSearch( const int array[], int key, int size )
{
    for (int i = 0; i < size; i++)
    {
        if (array[i] == key)
        {
            return i;
        }
    }
    return -1;
} 