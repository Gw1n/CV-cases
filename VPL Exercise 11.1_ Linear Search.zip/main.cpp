#include "search.h"
#include <iostream>

int main()
{
    const int max_size = 4;
    int key;
    int a[max_size];
    int size = 0;
    int& ref_size = size;
    std::cout << "Enter integers. Terminate with EOF." << std::endl;
    read(a, ref_size, max_size);
    std::cout << "The array has " << ref_size << " elements: "; 
    print(a, size);
    std::cout << "Please enter search key: ";
    std::cin >> key;
    if (linearSearch(a, key, size) == -1)
    {
        std::cout << "Search key not found among array elements!" << std::endl;
    }
    else
    {
        std::cout << "Search key found at index position " << linearSearch(a, key, size) << std::endl;
    }
}