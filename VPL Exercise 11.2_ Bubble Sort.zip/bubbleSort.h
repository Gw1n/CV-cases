#ifndef _BUBBLE_SORT_H_
#define _BUBBLE_SORT_H_

void read( int a[], int& size_ref, int max_size );
void print( const int a[], int size ); 
void bubbleSort(int a[], int size);

#endif