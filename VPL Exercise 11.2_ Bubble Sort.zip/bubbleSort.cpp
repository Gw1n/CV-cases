#include <iostream>

void read( int a[], int& size_ref, int max_size )
{
    size_ref = 0;
    while ((size_ref < max_size) && (!std::cin.eof()))
    {
        std::cout << "a[" << size_ref << "]: ";
        std::cin >> a[size_ref];
        size_ref++;
    }
    if (std::cin.eof())
        {
            std::cin.clear();
            size_ref--;
        }
}
void print( const int a[], int size )
{
    for (int i = 0; i < size; i++)
    {
        std::cout << a[i] << " ";
    }
}
void bubbleSort(int a[], int size)
{
    int change;
    for (int i = 1; i < size; i++)
    {
        for (int j = 0; j < size-i; j++)
        {
            if (a[j+1] < a[j])
            {
                change = a[j];
                a[j] = a[j+1];
                a[j+1] = change;
            }
        }
    }
    for (int i = 0; i < size; i++)
    {
        std::cout << a[i] << " ";
    }
}