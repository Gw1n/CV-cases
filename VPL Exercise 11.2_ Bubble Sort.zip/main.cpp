#include "bubbleSort.h"
#include <iostream>

int main()
{
    const int max_size = 5;
    int key;
    int a[max_size];
    int size = 0;
    int& ref_size = size;
    std::cout << "Enter integers. Terminate with EOF." << std::endl;
    read(a, ref_size, max_size);
    std::cout << "The array has " << ref_size << " elements: "; 
    print(a, size);
    std::cout << "After performing bubble sort, we get: ";
    bubbleSort(a, size);
}