#include "swap.h"
#include <iostream>

int main()
{
    int a = -1;
	int b = 2;
	int c = 3;

	int& ref_a = a;
	int& ref_b = b;
	int& ref_c = c;
	std::cout << a << " " << b << " " << c << std::endl;
	
	swap(ref_a,ref_b);
	std::cout << a << " " << b << " " << c << std::endl;
	
	//Test swap2
	swap2(ref_a,ref_b,ref_c,2,1);
	std::cout << a << " " << b << " " << c << std::endl;
	
	// swap only every 2nd time
	for(int i = 0; i < 5; i++) {
	    std::cout << swapcount(ref_a,ref_b) << std::endl;
	    std::cout << a << " " << b << " " << c << std::endl;
	}
}