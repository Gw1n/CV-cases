#include "swap.h"
#include <iostream>

void swap(int& a_ref,int& b_ref)
{
    int change_1 = b_ref;
    b_ref = a_ref;
    a_ref = change_1;
   
}

void swap2(int& a_ref,int& b_ref,int& c_ref, int first, int second)
{
    //std::cout << a_ref << " " << b_ref << " " << c_ref << " " << first << " " << second << std::endl;
    switch (first)
    {
        case(1):
        switch (second)
        {
            case(1):
            swap(a_ref, a_ref);
            break;
            case(2):
            swap(a_ref, b_ref);
            break;
            case(3):
            swap(a_ref, c_ref);
            break;
            default:
            swap(a_ref, second);
            break;
        }
        break;
        case(2):
        switch (second)
        {
            case(1):
            swap(b_ref, a_ref);
            break;
            case(3):
            swap(b_ref, c_ref);
            break;
            default:
            swap(b_ref, second);
            break;
        }
        break;
        case(3):
        switch (second)
        {
            case(1):
            swap(c_ref, a_ref);
            break;
            case(2):
            swap(c_ref, b_ref);
            break;
            default:
            swap(c_ref, second);
            break;
        }
        break;
        default:
        switch (second)
        {
            case(1):
            swap(first, a_ref);
            break;
            case(2):
            swap(first, b_ref);
            break;
            case(3):
            swap(first, c_ref);
            break;
            default:
            swap(first, second);
            break;
        }
        break;
    }
}

static int i = 0;
static int j = 0;

int swapcount(int& c_ref, int& d_ref)
{
    //std::cout << i << " " <<  j << " " << c_ref << " " << d_ref << std::endl;
    if ((i % 2 == 0) || (i == 0)) 
    {
        i++;
    }
    else 
    {
        swap(c_ref, d_ref);
        i++;
        j++;
    }
    return i;
}