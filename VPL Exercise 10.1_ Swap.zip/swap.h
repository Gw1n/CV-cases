#ifndef _SWAP_H_
#define _SWAP_H_

// Do not modify!!!

void swap(int& a_ref,int& b_ref);
void swap2(int& a_ref,int& b_ref,int& c_ref, int first, int second);
int swapcount(int& c_ref, int& d_ref);

#endif