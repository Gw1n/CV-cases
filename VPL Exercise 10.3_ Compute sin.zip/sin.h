#ifndef _SIN_H_
#define _SIN_H_

float sinIterative(float x); 
float sinRecursive(float x); 
float sinRecursive(float x, float quotient, int faculty);
float sinStatic(float x); 

#endif