#include <iostream>
using std::cin;
using std::cout;
using std::endl;
#include <cmath>
using std::sin;

#include "sin.h"

int main() {
  float x; 
  do {
    cout << "Please enter a floating point number: ";
    cin >> x;
    cout << "cmath: sin(x) = " << sin(x) << endl;
    cout << "myown: sin(x) = " << sinIterative(x) << endl;
    cout << "myrec: sin(x) = " << sinRecursive(x) << endl;
    cout << "mysma: sin(x) = " << sinStatic(x) << endl;
  } while(std::cin.good());
  return 0;
}
