#include "sin.h"
#include <cmath>
#include <iostream>

long factorial_recursion (long n)
{
    if (n == 0)
    {
        return 1;
    }
    else if (n < 0)
    {
        return 0;
    }
    else
    {
        n *= factorial_recursion(n-1);
        return n;
    }
}

float sinIterative(float x) 
{
    double sin_x = 0;
    int i = 0;
    while ((pow(x, (2*i+1))/factorial_recursion(2*i+1)) >= 0.0001)
    {
        sin_x += pow(-1, i) * (pow(x, (2*i+1))/factorial_recursion(2*i+1));
        i++;
    }
    sin_x += pow(-1, i) * (pow(x, (2*i+1))/factorial_recursion(2*i+1));
    return (sin_x);
} 

float sinRecursive(float x) 
{
    return sinRecursive(x, x, 1);
}

float sinRecursive(float x, float quotient, int faculty) 
{
    if (fabs(quotient) < 0.0001 ) {return quotient;}
    
    float nextTerm = -quotient*x*x/((faculty+1) * (faculty+2));
    
    return (quotient + sinRecursive(x, nextTerm, faculty+2));
}

//static float quotient;
static int faculty = 0;

float sinStatic(float x) 
{
    float quotient = pow(-1, faculty) * (pow(x, 2*faculty+1)/factorial_recursion(2*faculty+1));
    if (fabs(quotient) < 0.0001)
    {
        faculty = 0;
        return quotient;
    }
    faculty++;
    //std::cout << quotient << std::endl;
    return (quotient + sinStatic(x));
}