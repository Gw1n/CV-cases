#include <iostream>
#include <time.h>
#include "automaton.h"


void print_automaton(int automaton[], int size) 
{
    for (int i = 0; i < size; i++)
    {
        std::cout << ((automaton[i] == 1) ? '*':'.');
    }
    std::cout << "\n";
}


void init_automaton(int automaton[], int size) 
{
    static bool init = true;
    if(init)
    {
        srand(time(0));
        init = false;
    }
    automaton[0] = 0;
    automaton[size-1] = 0;
    
    for (int i = 1; i < size-1; i++)
    {
        automaton[i] = (rand() % 100 < 50) ? 0:1;
    }
}


void print_usage(const char name[]) 
{
    std::cout << "Usage:" << name << " <size> <generations>\n";
}


void create_new_generation(int automaton[], int size) 
{
    int copy[size];
    copy[0] = 0;
    copy[size] = 0;
    for (int i = 1; i < size-1; i++)
    {
        if ((automaton[i] == 0) && ((automaton[i-1] == 1) ^ (automaton[i+1] == 1)))
        {
            copy[i] = 1;
        }    
        else
        {
            copy[i] = 0;
        }
    }
    for (int i = 1; i < size-1; i++)
    {
        automaton[i] = copy[i];
    }
}