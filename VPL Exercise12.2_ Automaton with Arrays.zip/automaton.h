#ifndef AUTOMATON_H
#define AUTOMATON_H


/* Prints the array with '.' = 0 = empty
 * and '*' = 1 = full */
void print_automaton(int automaton[], int size);

/* Initializes the automaton randomly with
 * 0 and 1 */
void init_automaton(int automaton[], int size);

/* Prints out help message of the function
 * with name */
void print_usage(const char name[]);

void create_new_generation(int automaton[], int size);

#endif /* AUTOMATON_H */