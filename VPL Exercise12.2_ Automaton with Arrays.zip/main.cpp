#include <string>
#include <iostream>
#include "automaton.h"

using std::cout;
using std::endl;
using std::stoi;

int main(int argc, char const *argv[]) {
 
  //int size = 10;
  //int generations = 10;
  
  if(argc != 3) 
  {
    print_usage(argv[0]);
  } 
  else 
  {
    int size = stoi(argv[1]);
    int generations = stoi(argv[2]);
  
  int automaton[size]; 
  int automaton2[size]; 

  init_automaton(automaton, size);
  init_automaton(automaton2, size);
  
  print_automaton(automaton, size);
  print_automaton(automaton2, size);


  for(int i = 0; i < generations; i++) {
    print_automaton(automaton, size);
    create_new_generation(automaton, size);
  }
  }
  return 0;
}