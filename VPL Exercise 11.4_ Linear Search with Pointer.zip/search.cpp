#include "search.h"
#include <iostream>

void read (int* a_ptr, int* adress_offset_ptr, int max_offset)
{
    *adress_offset_ptr = 0;
    if (*adress_offset_ptr == 0)
    {
        std::cout << "No valid address\n";
    }
        
    while (!std::cin.eof() && (*adress_offset_ptr <= max_offset-1))
    {
        std::cout << "*(a_ptr + " << *adress_offset_ptr << "): ";
        std::cin >> a_ptr[*adress_offset_ptr];
        (*adress_offset_ptr)++;
    }
        
    if (std::cin.eof())
    {
        std::cin.clear();
        (*adress_offset_ptr)--;
    }

}

void print(const int* a_ptr, int adress_offset_ptr)
{
    for (int i = 0; i < adress_offset_ptr; i++)
    {
        std::cout << a_ptr[i] << " ";
    }
}

const int* linearSearch(const int* a_ptr, int key, int size)
{
    for (int i = 0; i < size; i++)
    {
        if (a_ptr[i] == key)
        {
            std::cout << "Search key found at index position " << i << std::endl;
            return &a_ptr[i];
        }
    }
    return nullptr;
}

/*
 * Implement all the functions without defining int arrays,
 * Try instead just using pointers and offsets
 * Use the given prototypes from the .h files
 */
