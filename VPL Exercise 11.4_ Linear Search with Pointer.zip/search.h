#ifndef SEARCH_H_
#define SEARCH_H_

void read(int* a, int* size, int max_size);
void print(const int*, int);
const int* linearSearch(const int* array, int key, int size);

#endif